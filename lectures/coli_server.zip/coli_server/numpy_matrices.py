import time
import numpy as np
import torch

# Define the size of the matrices
matrix_size = 1000

# Create two random matrices of size matrix_size x matrix_size
matrix_a_cpu = np.random.rand(matrix_size, matrix_size)
matrix_b_cpu = np.random.rand(matrix_size, matrix_size)

# GPU version using PyTorch
# Convert the matrices to PyTorch tensors and move them to the GPU
matrix_a_gpu = torch.tensor(matrix_a_cpu, dtype=torch.float32, device='cuda')
matrix_b_gpu = torch.tensor(matrix_b_cpu, dtype=torch.float32, device='cuda')

# Compute element-wise product on GPU
start_time_gpu = time.time()
matrix_result_gpu = matrix_a_gpu * matrix_b_gpu
end_time_gpu = time.time()
gpu_time = end_time_gpu - start_time_gpu

print(f"Element-wise product on GPU took {gpu_time:.5f} seconds.")

# CPU version using NumPy
start_time_cpu = time.time()
matrix_result_cpu = np.multiply(matrix_a_cpu, matrix_b_cpu)
end_time_cpu = time.time()
cpu_time = end_time_cpu - start_time_cpu

print(f"Element-wise product on CPU took {cpu_time:.5f} seconds.")

# Speedup calculation
