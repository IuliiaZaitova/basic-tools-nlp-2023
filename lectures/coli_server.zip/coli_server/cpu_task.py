import time
import torch

def factorial_on_cpu(n):
    start_time = time.time()
    result = 1
    for i in range(1, n + 1):
        result *= i
    end_time = time.time()
    cpu_time = end_time - start_time
    return cpu_time, result

def factorial_on_gpu(n):
    # Convert the number to a PyTorch tensor and move it to the GPU
    n_gpu = torch.tensor(n, dtype=torch.int64, device='cuda')

    start_time = time.time()
    result = 1
    for i in range(1, n_gpu.item() + 1):
        result *= i
    end_time = time.time()
    gpu_time = end_time - start_time
    return gpu_time, result

if __name__ == "__main__":
    number = 500

    cpu_time, cpu_result = factorial_on_cpu(number)
    print(f"Factorial on CPU took {cpu_time:.5f} seconds.")
    #print(f"Factorial (CPU): {cpu_result}")

    gpu_time, gpu_result = factorial_on_gpu(number)
    print(f"Factorial on GPU took {gpu_time:.5f} seconds.")
    #print(f"Factorial (GPU): {gpu_result}")
